# FilelessPELoader

Loading Remote AES Encrypted PE in memory , Decrypted it and run it


### Usage :
![CipherKey](https://raw.githubusercontent.com/illegal-instruction-co/FilelessPELoader/main/assets/1.png)

![filelessremotepe](https://raw.githubusercontent.com/illegal-instruction-co/FilelessPELoader/main/assets/2.png)

### References :

https://github.com/aplyc1a/PEMemoryLoader?fbclid=IwAR2-VAQo8pJU-tdbSENjhDBdDGi5tyzrnW1S3D9BPAYR6C6-RK4hsEDjDGk

https://github.com/Octoberfest7/Inline-Execute-PE

### Requirements
1. hashlib
2. pycryptodome
3. pycryptodomex
